import React, { memo, useContext, useEffect, useState } from 'react'
import { Text, Dimensions, Image, View, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { AppContext } from '../context/AppContext';
import { SwiperFlatList } from 'react-native-swiper-flatlist';
import { LinearGradient } from 'expo-linear-gradient';
import * as Animatable from 'react-native-animatable';
import { FontAwesome, AntDesign, Ionicons, MaterialCommunityIcons, FontAwesome5, MaterialIcons, Feather } from "@expo/vector-icons";
const { width } = Dimensions.get('window');
const ProductView = memo(({navigation,route}) => {
    const {productId,startIndex} = route.params;
    const {appState:{
        selectedProducts,
        fontFamilyObj:{fontLight,fontBold},
        setModalState,
        cart,setCart
    }} = useContext(AppContext);
    return (
        <View style={{flex:1}}>
            <View style={{padding:10}}>
                <TouchableOpacity style={{flexDirection:'row',borderWidth:1,padding:10,borderColor:'#14678B',borderRadius:10}} onPress={() => navigation.navigate("Cart")}>
                    <View style={{flex:1}}>
                        <MaterialCommunityIcons name='cart-heart' size={30} color="#757575" style={{marginTop:4}}></MaterialCommunityIcons>
                    </View>
                    <View style={{alignContent:'center',alignItems:'center',justifyContent:'center'}}>
                        <Text style={{fontFamily:fontBold,fontSize:Platform.OS === 'android' ? 11 : 13}}>PROCEED TO CHECKOUT</Text>
                        <Text style={{fontFamily:fontBold,fontSize:Platform.OS === 'android' ? 11 : 14,color:'green'}}>ZAR {cart.length > 0 ? (cart.reduce((total, obj) => (parseFloat(obj.price) * parseFloat(obj.quantity)) + total,0)).toFixed(2) : '0.00'}</Text>
                    </View>
                </TouchableOpacity>
            </View>
            <SwiperFlatList index={startIndex}>
                {selectedProducts?.map((item,i) => {
                    let itemInCart = false;
                    const {price,discount,productUrl,productId,productName} = item;
                    const buyingPrice = (parseFloat(price) - (parseFloat(discount) / 100) * parseFloat(price)).toFixed(2)
                    cart.filter(item => item.productId === productId).length > 0 ? itemInCart = true : itemInCart = false;
  
                    return(
                        <ScrollView key={i} style={{width:width,padding:7}} showsVerticalScrollIndicator={false}>
                            <View style={{backgroundColor:'rgba(0, 0, 0, 0.1)',borderRadius:30,justifyContent:'center',alignContent:'center',alignItems:'center',padding:10}}>
                                <Image source={{uri:productUrl}} style={{width:'98%',aspectRatio:1,borderRadius:30}} />
                            </View>
                            <LinearGradient colors={["rgba(0, 0, 0, 0.1)","rgba(0, 0, 0, 0.1)","#14678B","#EFEFEF"]} start={{ x: 0, y: 1 }} end={{ x: 1, y: 0 }} style={{minHeight:70,alignItems:'center',justifyContent:'center',paddingLeft:15,paddingRight:15,borderTopLeftRadius:50,borderBottomRightRadius:50,marginTop:15}}>  
                                <Animatable.View animation="slideInRight" duration={1500} useNativeDriver={true} style={{width:'100%',flexDirection:'row'}}>
                                    <Feather name='list' color={"#14678B"} size={30} style={{flex:1}}></Feather>
                                    <Text style={{color:'#fff',fontFamily:fontLight}}>{productName}</Text>
                                </Animatable.View>
                            </LinearGradient>
                            <View style={{marginTop:5,padding:5}}>
                                <Text style={{color:'#757575',fontFamily:fontLight}}>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy</Text>
                            </View>
                            <View style={{flexDirection:'row',marginTop:10,padding:10,borderBottomWidth:1,borderBottomColor:'#BABEC1',paddingBottom:20}}>
                                <Text style={{fontFamily:fontBold,flex:1,textDecorationLine: 'line-through', textDecorationStyle: 'solid',padding:10}}>ZAR {parseFloat(price).toFixed(2)}</Text>
                                <Text style={{fontFamily:fontBold,color:'green',borderWidth:1,padding:10,borderColor:'green',borderRadius:10}}>ZAR {buyingPrice}</Text>
                            </View>
                            <View style={{marginTop:20,flexDirection:'row',paddingBottom:60}}>
                                <TouchableOpacity onPress={()=>navigation.goBack()} style={{width:'20%',alignContent:'center',alignContent:'center',justifyContent:'center'}}>
                                    <Feather name='arrow-left-circle' color={"tomato"} size={40}></Feather>
                                </TouchableOpacity>
                                
                                {!itemInCart && 
                                    <TouchableOpacity onPress={()=>{
                                        setCart([...cart,{...item,price:buyingPrice,quantity:1,status:"SHIPPING"}])
                                        setModalState({isVisible:true,attr:{headerText:'ADD TO CART',productId}});
                                    }} style={{flexDirection:'row',borderWidth:1,padding:10,borderColor:'#14678B',borderRadius:10,width:'70%',marginLeft:'9%'}}>
                                        <View style={{flex:1}}>
                                            <MaterialCommunityIcons name='cart-plus' size={36} color="green"></MaterialCommunityIcons>
                                        </View>
                                        <View style={{alignContent:'center',alignItems:'center',justifyContent:'center'}}>
                                            <Text style={{fontFamily:fontBold,fontSize:Platform.OS === 'android' ? 12 : 14,color:'green'}}>ADD TO CART</Text>
                                        </View>
                                    </TouchableOpacity>
                                }
                                {itemInCart && 
                                    <TouchableOpacity onPress={()=>{
                                        setCart(cart.filter(item => item.productId !== productId))
                                    }} style={{flexDirection:'row',borderWidth:1,padding:10,borderColor:'#14678B',borderRadius:10,width:'70%',marginLeft:'9%'}}>
                                        <View style={{flex:1}}>
                                            <MaterialCommunityIcons name='cart-minus' size={36} color="tomato"></MaterialCommunityIcons>
                                        </View>
                                        <View style={{alignContent:'center',alignItems:'center',justifyContent:'center'}}>
                                            <Text style={{fontFamily:fontBold,fontSize:Platform.OS === 'android' ? 12 : 14,color:'tomato'}}>REMOVE FROM CART</Text>
                                        </View>
                                    </TouchableOpacity>
                                }
                            </View>
                        </ScrollView>
                    )
                })}
            </SwiperFlatList>
        </View>
    )
})

export default ProductView