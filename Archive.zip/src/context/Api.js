import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs, doc, setDoc, query, where, deleteDoc, updateDoc, onSnapshot   } from 'firebase/firestore';
import { getStorage, ref, getDownloadURL, uploadBytesResumable } from "firebase/storage";
import * as Network from 'expo-network';
import * as st from "firebase/storage";
const firebaseConfig = {
    apiKey: "AIzaSyBnZwEvXFmWS73BBIIX7MBbZKYftcHnm2o",
    authDomain: "certified-71c37.firebaseapp.com",
    projectId: "certified-71c37",
    storageBucket: "certified-71c37.appspot.com",
    messagingSenderId: "844342179371",
    appId: "1:844342179371:web:a5c3688f5babb7b4401c6e"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();
export const createData = async (tableName,docId,data) => {
    try {
        await setDoc(doc(db, tableName, docId), data);
        return true;
    } catch (e) {
        alert(e)
        return false;
    }
}
export const loginApi = async (phoneNumber,password,cb) => {
    try {
        const querySnapshot = await getDocs(query(collection(db, "clients"), where("phoneNumber", "==", phoneNumber), where("password", "==", password)));
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data)
    } catch (e) {
        cb(e);
    }
}
export const getUserDetails = async (accountId,cb) => {
    try {
        const querySnapshot = await getDocs(query(collection(db, "clients"), where("id", "==", accountId)));
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data)
    } catch (e) {
        cb(e);
    }
}
export const getMyProducts = async (accountId,cb) => {
    try {
        const querySnapshot = await getDocs(query(collection(db, "purchases"), where("accountId", "==", accountId)));
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data)
    } catch (e) {
        cb(e);
    }
}
export const getTrending = async (cb) => {
    try {
        const querySnapshot = await getDocs(query(collection(db, "purchases")));
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data)
    } catch (e) {
        cb(e);
    }
}
export const verifyItem = async (itemId,cb) => {
    try {
        const querySnapshot = await getDocs(query(collection(db, "productItems"), where("itemId", "==", itemId)));
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data)
    } catch (e) {
        cb(e);
    }
}
export const getProductList = async (cb) => {
    try {
        const querySnapshot = await getDocs(query(collection(db, "productList")));
        const data = querySnapshot.docs.map(doc => doc.data());
        cb(data)
    } catch (e) {
        cb(e);
    }
}
export const updateData = async (tableName,docId,obj) => {
    try {
        const docRef = doc(db, tableName, docId);
        await updateDoc(docRef, obj);
        return true;
    } catch (e) {
        return false;
    }
}
export const uploadFile = async (file,path,cb) =>{
    const storage = st.getStorage(app);
    const fileRef = st.ref(storage, path);
    const response = await fetch(file);
    const blob = await response.blob();
    const uploadTask = await st.uploadBytesResumable(fileRef, blob);
    const url = await st.getDownloadURL(uploadTask.ref);
    cb(url)
}