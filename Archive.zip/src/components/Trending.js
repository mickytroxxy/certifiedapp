import PropTypes from 'prop-types'
import React, { memo,useContext,useEffect,useState } from 'react'
import { View,TouchableOpacity,Text, ScrollView, Image, Platform } from 'react-native'
import { AppContext } from '../context/AppContext'
import * as Animatable from 'react-native-animatable';
import { getTrending } from '../context/Api';
import moment from 'moment';
import { AntDesign, EvilIcons, Feather } from "@expo/vector-icons";
const Trending = memo(({navigation}) => {
    const {appState:{
        fontFamilyObj:{fontBold,fontLight},
    }} = useContext(AppContext);
    const [trending,setTrending] = useState(null);
    useEffect(()=>{
        getTrending(response => setTrending(response))
    },[])
    return (
        <View>
            <ScrollView style={{marginTop:15}}>
                    <Animatable.View style={{marginTop:10}} animation="fadeInUpBig" duration={1000} useNativeDriver={true}> 
                    {trending?.map((mainCart) => {
                        return mainCart.cart.map((item,i) => {
                            const {category,productUrl,price,brandName,status} = item
                            return(
                                <TouchableOpacity key={i} style={{height:100,alignItems:'center',backgroundColor:'rgba(0, 0, 0, 0.1)',marginBottom:5,justifyContent:'center',padding:10,borderRadius:5,flexDirection:'row'}}>
                                    <View style={{flex:1,justifyContent:'center',alignContent:'center',alignItems:'center'}}>
                                    <View style={{height:80,width:80,borderRadius:10,backgroundColor:'#fff',justifyContent:'center',alignItems:'center'}}>
                                        <Image source={{uri:productUrl}} style={{height:75,width:75,borderRadius:10}}/>
                                    </View>
                                    </View>
                                    <View style={{flex:3,marginLeft:10}}>
                                        <Text style={{color:'#14678B',fontFamily:fontBold}}>{brandName?.toUpperCase()} {category}</Text>
                                        <Text style={{color:'#6B8597',fontFamily:Platform.OS === 'ios' ? fontBold : fontLight}}>Price (ZAR {parseFloat(price).toFixed(2)})</Text>
                                        <Text style={{color:'#6B8597',fontFamily:Platform.OS === 'ios' ? fontBold : fontLight}}>{moment(mainCart.date).format("YYYY-MM-DD")}</Text>
                                    </View>
                                </TouchableOpacity>
                            )
                        })
                    })}
                </Animatable.View>
            </ScrollView>
        </View>
    )
})

Trending.propTypes = {}

export default Trending