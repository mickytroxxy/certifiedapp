import PropTypes from 'prop-types'
import React, { memo,useContext,useState } from 'react'
import { View,TouchableOpacity,Text, ScrollView, Image, Platform } from 'react-native'
import { AppContext } from '../context/AppContext'
import * as Animatable from 'react-native-animatable';
const Products = memo(({navigation}) => {
    const {appState:{
        fontFamilyObj:{fontBold,fontLight},
        filters,
        setFilters,
        setModalState,
        selectedProducts
    }} = useContext(AppContext);
    
    const handleFilters = (filter,selectedItem) => setFilters(filters.map(item => item.type === filter ? {...item,subItems:item.subItems.map(x => x.type === selectedItem ? {...x,selected:true} : {...x,selected:false})} : item))
    return (
        <View>
            <Animatable.View animation="slideInLeft" duration={750} useNativeDriver={true} style={{flexDirection:'row',marginTop:10,borderBottomWidth:0.6,borderBottomColor:'#fff',paddingBottom:15}}>
                {filters?.map((item,i) => {
                    return(
                        <View key={i} style={{flex:1}}>
                            <TouchableOpacity style={{borderWidth:1,borderColor:'#5586cc',flex:1,margin:5,padding:10,borderRadius:30}} onPress={() => {
                                setModalState({isVisible:true,attr:{headerText:'SELECT '+item.type,item,handleFilters}});
                            }}>
                                <Text style={{fontFamily:fontBold,color:'#757575',textAlign:'center',fontSize:Platform.OS === 'android' ? 11 : 14}}>{item.type}</Text>
                            </TouchableOpacity>
                            <TouchableOpacity><Text style={{textAlign:'center',fontFamily:fontBold,color:'#5586cc'}}>{item?.subItems?.filter(item => item.selected === true)[0].type}</Text></TouchableOpacity>
                        </View>
                    )
                })}
            </Animatable.View>

            <ScrollView style={{marginTop:15}}>
                <Animatable.View animation="slideInRight" duration={750} useNativeDriver={true} style={{flexDirection:'row',alignContent:'center',alignItems:'center',display: 'flex', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',flexWrap: 'wrap'}}>
                    {selectedProducts?.map((item,i)=>{
                        const {price,discount,productUrl,productId} = item;
                        return(
                        <TouchableOpacity onPress={() => navigation.navigate("ProductView",{productId,startIndex:i})} key={i} style={{width:'48%',borderRadius:10,alignContent:'center',alignItems:'center',justifyContent:'center',minHeight:220,marginTop:10}}>
                            <View style={{width:'100%',height:220,backgroundColor:'#fff',borderRadius:10,padding:2,alignContent:'center',justifyContent:'center',alignItems:'center'}}>
                                <Image source={{uri:productUrl}} style={{width:'100%',height:'100%',borderRadius:10}} />
                            </View>
                            <View style={{backgroundColor:'rgba(0, 0, 0, 0.2)',borderRadius:0,justifyContent:'center',borderBottomRightRadius:50,borderTopLeftRadius:50,padding:10,width:'100%',marginTop:5}}><Text style={{fontFamily:fontBold,color:'#14678B',textAlign:'center'}}>ZAR {(parseFloat(price) - (parseFloat(discount) / 100) * parseFloat(price)).toFixed(2)}</Text></View>
                        </TouchableOpacity>
                        )
                    })}
                </Animatable.View>
            </ScrollView>
        </View>
    )
})

Products.propTypes = {}

export default Products